package com.example.persiankeyboard

import android.content.Context

/**
 * Stores the custom replacement text the user has configured for each
 * letter. Double-tapping a letter key on the keyboard inserts the text
 * stored here for that letter, instead of the letter itself.
 */
class ReplacementStore(context: Context) {

    private val prefs = context.getSharedPreferences("replacements", Context.MODE_PRIVATE)

    fun getReplacement(letter: String): String? {
        val value = prefs.getString(keyFor(letter), null)
        return if (value.isNullOrEmpty()) null else value
    }

    fun setReplacement(letter: String, text: String) {
        prefs.edit().putString(keyFor(letter), text).apply()
    }

    fun clearReplacement(letter: String) {
        prefs.edit().remove(keyFor(letter)).apply()
    }

    fun getAll(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        for (letter in KeyboardData.allLetters()) {
            getReplacement(letter)?.let { result[letter] = it }
        }
        return result
    }

    private fun keyFor(letter: String) = "letter_$letter"

    // Auto-type delay between characters, in milliseconds.
    // Lower = faster typing. Stored so the chosen speed is remembered.
    fun getAutoTypeDelayMs(): Int = prefs.getInt("autotype_delay_ms", 90)

    fun setAutoTypeDelayMs(delayMs: Int) {
        prefs.edit().putInt("autotype_delay_ms", delayMs).apply()
    }

    companion object {
        // How long (ms) between two taps on the same key still counts as a double-tap
        const val DOUBLE_TAP_WINDOW_MS = 350L
    }
}
