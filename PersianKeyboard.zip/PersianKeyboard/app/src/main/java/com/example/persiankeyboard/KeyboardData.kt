package com.example.persiankeyboard

/**
 * Defines the character rows for each keyboard layout.
 * Special keys (backspace, space, enter, switch, autotype) are added
 * separately by the KeyboardView / Service, these lists are letters only.
 */
object KeyboardData {

    // Common Persian phone keyboard layout (3 letter rows)
    val PERSIAN_ROWS: List<List<String>> = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ"),
        listOf("ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ"),
        listOf("ظ", "ط", "ز", "ر", "ذ", "د", "پ", "و", "ژ")
    )

    // Standard English QWERTY layout (3 letter rows)
    val ENGLISH_ROWS: List<List<String>> = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )

    // Flat list of every letter across both layouts, used to build the
    // "customize replacement text" settings screen.
    fun allLetters(): List<String> {
        val list = mutableListOf<String>()
        PERSIAN_ROWS.forEach { row -> list.addAll(row) }
        ENGLISH_ROWS.forEach { row -> list.addAll(row) }
        return list
    }
}
