package com.example.persiankeyboard

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Each row saves its own text as it's typed (via TextWatcher), so nothing
 * is lost when a row scrolls off-screen and gets recycled.
 */
class LetterAdapter(
    private val letters: List<String>,
    private val store: ReplacementStore
) : RecyclerView.Adapter<LetterAdapter.LetterHolder>() {

    class LetterHolder(view: View) : RecyclerView.ViewHolder(view) {
        val label: TextView = view.findViewById(R.id.letterLabel)
        val input: EditText = view.findViewById(R.id.replacementInput)
        var watcher: TextWatcher? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LetterHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_letter, parent, false)
        return LetterHolder(view)
    }

    override fun onBindViewHolder(holder: LetterHolder, position: Int) {
        val letter = letters[position]
        holder.label.text = letter

        // Remove any previous watcher before rebinding (recycled view holder)
        holder.watcher?.let { holder.input.removeTextChangedListener(it) }

        holder.input.setText(store.getReplacement(letter) ?: "")

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val text = s?.toString() ?: ""
                if (text.isEmpty()) {
                    store.clearReplacement(letter)
                } else {
                    store.setReplacement(letter, text)
                }
            }
        }
        holder.input.addTextChangedListener(watcher)
        holder.watcher = watcher
    }

    override fun getItemCount(): Int = letters.size
}
