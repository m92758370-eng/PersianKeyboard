package com.example.persiankeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat

enum class KeyType { LETTER, SPACE, BACKSPACE, ENTER, SWITCH, AUTOTYPE }

data class KeyModel(
    val label: String,
    val type: KeyType,
    var rect: RectF = RectF()
)

interface KeyboardActionListener {
    /** A letter key was tapped a single time (normal typing). */
    fun onLetter(letter: String)
    /** The same letter key was tapped twice quickly -> use replacement text instead. */
    fun onLetterDoubleTap(letter: String)
    fun onBackspace()
    fun onSpace()
    fun onEnter()
    fun onSwitchLayout()
    fun onToggleAutoTypePanel()
}

class KeyboardView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    var listener: KeyboardActionListener? = null

    var rows: List<List<String>> = KeyboardData.PERSIAN_ROWS
        set(value) {
            field = value
            requestLayout()
            invalidate()
        }

    private val keys = mutableListOf<KeyModel>()

    private var highlightedLabel: String? = null

    private var pressedKey: KeyModel? = null

    // Double tap tracking
    private var lastTapLabel: String? = null
    private var lastTapTime: Long = 0

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaintSpecial = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaintPressed = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaintHighlight = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        bgPaint.color = ContextCompat.getColor(context, R.color.key_bg)
        bgPaintSpecial.color = ContextCompat.getColor(context, R.color.key_bg_special)
        bgPaintPressed.color = ContextCompat.getColor(context, R.color.key_bg_pressed)
        bgPaintHighlight.color = ContextCompat.getColor(context, R.color.key_bg_highlight)
        textPaint.color = ContextCompat.getColor(context, R.color.key_text)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 42f
        setBackgroundColor(ContextCompat.getColor(context, R.color.keyboard_bg))
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys(w, h)
    }

    private fun layoutKeys(w: Int, h: Int) {
        keys.clear()
        val totalRows = rows.size + 2 // + special row + bottom row
        val rowHeight = h / totalRows.toFloat()
        val margin = 6f

        var y = 0f
        for (row in rows) {
            val keyWidth = w / row.size.toFloat()
            var x = 0f
            for (label in row) {
                keys.add(
                    KeyModel(
                        label,
                        KeyType.LETTER,
                        RectF(x + margin, y + margin, x + keyWidth - margin, y + rowHeight - margin)
                    )
                )
                x += keyWidth
            }
            y += rowHeight
        }

        // Special row: switch language + autotype toggle
        run {
            val specialWidth = w / 2f
            keys.add(
                KeyModel(
                    "🌐",
                    KeyType.SWITCH,
                    RectF(margin, y + margin, specialWidth - margin, y + rowHeight - margin)
                )
            )
            keys.add(
                KeyModel(
                    "⏵ خودکار",
                    KeyType.AUTOTYPE,
                    RectF(specialWidth + margin, y + margin, w - margin, y + rowHeight - margin)
                )
            )
            y += rowHeight
        }

        // Bottom row: backspace, space, enter
        run {
            val backspaceWidth = w * 0.2f
            val enterWidth = w * 0.2f
            val spaceWidth = w - backspaceWidth - enterWidth

            keys.add(
                KeyModel("⌫", KeyType.BACKSPACE, RectF(margin, y + margin, backspaceWidth - margin, y + rowHeight - margin))
            )
            keys.add(
                KeyModel(
                    "␣",
                    KeyType.SPACE,
                    RectF(backspaceWidth + margin, y + margin, backspaceWidth + spaceWidth - margin, y + rowHeight - margin)
                )
            )
            keys.add(
                KeyModel(
                    "⏎",
                    KeyType.ENTER,
                    RectF(backspaceWidth + spaceWidth + margin, y + margin, w - margin, y + rowHeight - margin)
                )
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (key in keys) {
            val paint = when {
                key.label == highlightedLabel -> bgPaintHighlight
                key == pressedKey -> bgPaintPressed
                key.type == KeyType.LETTER -> bgPaint
                else -> bgPaintSpecial
            }
            canvas.drawRoundRect(key.rect, 14f, 14f, paint)
            val textY = key.rect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2
            canvas.drawText(key.label, key.rect.centerX(), textY, textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val key = findKeyAt(event.x, event.y)
                pressedKey = key
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                val key = findKeyAt(event.x, event.y)
                pressedKey = null
                if (key != null) {
                    handleKeyTap(key)
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedKey = null
                invalidate()
            }
        }
        return true
    }

    private fun findKeyAt(x: Float, y: Float): KeyModel? {
        return keys.firstOrNull { it.rect.contains(x, y) }
    }

    private fun handleKeyTap(key: KeyModel) {
        when (key.type) {
            KeyType.LETTER -> {
                val now = SystemClock.uptimeMillis()
                val isDoubleTap = key.label == lastTapLabel &&
                    (now - lastTapTime) <= ReplacementStore.DOUBLE_TAP_WINDOW_MS
                if (isDoubleTap) {
                    listener?.onLetterDoubleTap(key.label)
                    // reset so a third tap doesn't chain into another double-tap
                    lastTapLabel = null
                    lastTapTime = 0
                } else {
                    listener?.onLetter(key.label)
                    lastTapLabel = key.label
                    lastTapTime = now
                }
            }
            KeyType.BACKSPACE -> listener?.onBackspace()
            KeyType.SPACE -> listener?.onSpace()
            KeyType.ENTER -> listener?.onEnter()
            KeyType.SWITCH -> listener?.onSwitchLayout()
            KeyType.AUTOTYPE -> listener?.onToggleAutoTypePanel()
        }
    }

    /** Highlights the key matching [char] briefly (used during auto-type playback). */
    fun highlightChar(char: Char?) {
        highlightedLabel = char?.toString()
        invalidate()
    }
}
