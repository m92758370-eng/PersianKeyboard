package com.example.persiankeyboard

import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.SeekBar

class PersianInputMethodService : InputMethodService(), KeyboardActionListener {

    private lateinit var container: FrameLayout
    private lateinit var keyboardView: KeyboardView
    private lateinit var replacementStore: ReplacementStore

    private var usingPersian = true

    private val mainHandler = Handler(Looper.getMainLooper())
    private var autoTypeRunnable: Runnable? = null
    private var autoTypeText: String = ""
    private var autoTypeIndex: Int = 0
    private var autoTypeDelayMs: Int = 90

    override fun onCreateInputView(): View {
        replacementStore = ReplacementStore(this)
        autoTypeDelayMs = replacementStore.getAutoTypeDelayMs()

        container = FrameLayout(this)

        keyboardView = KeyboardView(this)
        keyboardView.listener = this
        keyboardView.rows = if (usingPersian) KeyboardData.PERSIAN_ROWS else KeyboardData.ENGLISH_ROWS
        keyboardView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            dpToPx(230)
        )

        container.addView(keyboardView)
        return container
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        stopAutoType()
        showKeyboard()
    }

    // ---- KeyboardActionListener ----

    override fun onLetter(letter: String) {
        currentInputConnection?.commitText(letter, 1)
    }

    override fun onLetterDoubleTap(letter: String) {
        val replacement = replacementStore.getReplacement(letter)
        if (replacement != null) {
            // Remove the single character that was already committed on the first tap
            currentInputConnection?.deleteSurroundingText(1, 0)
            currentInputConnection?.commitText(replacement, 1)
        }
        // If no replacement is configured for this letter, the second tap
        // simply behaves like a normal letter tap.
        else {
            currentInputConnection?.commitText(letter, 1)
        }
    }

    override fun onBackspace() {
        currentInputConnection?.deleteSurroundingText(1, 0)
    }

    override fun onSpace() {
        currentInputConnection?.commitText(" ", 1)
    }

    override fun onEnter() {
        currentInputConnection?.commitText("\n", 1)
    }

    override fun onSwitchLayout() {
        usingPersian = !usingPersian
        keyboardView.rows = if (usingPersian) KeyboardData.PERSIAN_ROWS else KeyboardData.ENGLISH_ROWS
    }

    override fun onToggleAutoTypePanel() {
        showAutoTypePanel()
    }

    // ---- View swapping ----

    private fun showKeyboard() {
        container.removeAllViews()
        container.addView(keyboardView)
    }

    private fun showAutoTypePanel() {
        stopAutoType()
        val panel = LayoutInflater.from(this).inflate(R.layout.auto_type_panel, container, false)
        container.removeAllViews()
        container.addView(panel)

        val input = panel.findViewById<EditText>(R.id.autoTypeInput)
        val seekBar = panel.findViewById<SeekBar>(R.id.speedSeekBar)
        val startBtn = panel.findViewById<Button>(R.id.startAutoTypeBtn)
        val stopBtn = panel.findViewById<Button>(R.id.stopAutoTypeBtn)
        val closeBtn = panel.findViewById<Button>(R.id.closeAutoTypeBtn)

        // seekBar progress -> delay: higher progress = faster (lower delay)
        seekBar.max = 380
        seekBar.progress = 400 - autoTypeDelayMs

        startBtn.setOnClickListener {
            val text = input.text.toString()
            if (text.isNotEmpty()) {
                val delay = 400 - seekBar.progress
                autoTypeDelayMs = delay.coerceIn(20, 400)
                replacementStore.setAutoTypeDelayMs(autoTypeDelayMs)
                startAutoType(text)
            }
        }

        stopBtn.setOnClickListener {
            stopAutoType()
        }

        closeBtn.setOnClickListener {
            stopAutoType()
            showKeyboard()
        }
    }

    // ---- Auto-type playback ----

    private fun startAutoType(text: String) {
        stopAutoType()
        autoTypeText = text
        autoTypeIndex = 0

        // Show the real keyboard behind the scenes so keys can be highlighted
        // as each character is "typed".
        container.removeAllViews()
        container.addView(keyboardView)

        val step = object : Runnable {
            override fun run() {
                if (autoTypeIndex >= autoTypeText.length) {
                    keyboardView.highlightChar(null)
                    return
                }
                val c = autoTypeText[autoTypeIndex]

                // Switch layout automatically if the next character doesn't
                // match the currently active layout, so the highlight lines up.
                val isPersianChar = c.code in 0x0600..0x06FF
                if (isPersianChar != usingPersian && c != ' ' && c != '\n') {
                    usingPersian = isPersianChar
                    keyboardView.rows = if (usingPersian) KeyboardData.PERSIAN_ROWS else KeyboardData.ENGLISH_ROWS
                }

                keyboardView.highlightChar(c)
                when (c) {
                    '\n' -> currentInputConnection?.commitText("\n", 1)
                    else -> currentInputConnection?.commitText(c.toString(), 1)
                }

                autoTypeIndex++
                mainHandler.postDelayed(this, autoTypeDelayMs.toLong())
            }
        }
        autoTypeRunnable = step
        mainHandler.post(step)
    }

    private fun stopAutoType() {
        autoTypeRunnable?.let { mainHandler.removeCallbacks(it) }
        autoTypeRunnable = null
        if (::keyboardView.isInitialized) {
            keyboardView.highlightChar(null)
        }
    }

    private fun dpToPx(dp: Int): Int {
        val density = resources.displayMetrics.density
        return (dp * density).toInt()
    }
}
