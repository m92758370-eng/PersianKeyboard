package com.example.persiankeyboard

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val store = ReplacementStore(this)
        val letters = KeyboardData.allLetters()

        val list = findViewById<RecyclerView>(R.id.letterList)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = LetterAdapter(letters, store)

        // Text is already saved live as the user types (see LetterAdapter),
        // this button just gives clear confirmation feedback.
        findViewById<android.widget.Button>(R.id.saveButton).setOnClickListener {
            Toast.makeText(this, "ذخیره شد", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
